
package org.hibernate.validator.internal.util.logging;

import java.io.Serializable;
import javax.annotation.Generated;


/**
 * Warning this class consists of generated code.
 * 
 */
@Generated(value = "org.jboss.logging.processor.model.MessageBundleImplementor", date = "2014-05-06T15:07:00+0200")
public class Messages_$bundle
    implements Serializable, Messages
{

    private final static long serialVersionUID = 1L;
    private final static String projectCode = "HV";
    public final static Messages_$bundle INSTANCE = new Messages_$bundle();
    private final static String classCannotBeNull = "The class cannot be null.";
    private final static String propertyPathCannotBeNull = "null is not allowed as property path.";
    private final static String validatedConstructorMustNotBeNull = "The constructor to be validated must not be null.";
    private final static String mustNotBeNull0 = "must not be null.";
    private final static String validatedConstructorCreatedInstanceMustNotBeNull = "The created instance must not be null.";
    private final static String inputStreamCannotBeNull = "The input stream for #addMappging() cannot be null.";
    private final static String validatedObjectMustNotBeNull = "The object to be validated must not be null.";
    private final static String beanTypeMustNotBeNull = "The bean type must not be null when creating a constraint mapping.";
    private final static String classIsNull = "Class is null.";
    private final static String beanTypeCannotBeNull = "The bean type cannot be null.";
    private final static String unableToFindScriptEngine = "No JSR 223 script engine found for language \"%s\".";
    private final static String parameterMustNotBeEmpty = "The parameter \"%s\" must not be empty.";
    private final static String propertyNameMustNotBeEmpty = "The property name must not be empty.";
    private final static String parameterMustNotBeNull = "The parameter \"%s\" must not be null.";
    private final static String groupMustNotBeNull = "null passed as group name.";
    private final static String mustNotBeNull1 = "%s must not be null.";
    private final static String validatedParameterArrayMustNotBeNull = "The method parameter array cannot not be null.";
    private final static String methodNameMustNotBeNull = "The method name must not be null.";
    private final static String validatedMethodMustNotBeNull = "The method to be validated must not be null.";

    protected Messages_$bundle() {
    }

    protected Object readResolve() {
        return INSTANCE;
    }

    public final String classCannotBeNull() {
        String result = classCannotBeNull$str();
        return result;
    }

    protected String classCannotBeNull$str() {
        return classCannotBeNull;
    }

    public final String propertyPathCannotBeNull() {
        String result = propertyPathCannotBeNull$str();
        return result;
    }

    protected String propertyPathCannotBeNull$str() {
        return propertyPathCannotBeNull;
    }

    public final String validatedConstructorMustNotBeNull() {
        String result = validatedConstructorMustNotBeNull$str();
        return result;
    }

    protected String validatedConstructorMustNotBeNull$str() {
        return validatedConstructorMustNotBeNull;
    }

    public final String mustNotBeNull() {
        String result = mustNotBeNull0$str();
        return result;
    }

    protected String mustNotBeNull0$str() {
        return mustNotBeNull0;
    }

    public final String validatedConstructorCreatedInstanceMustNotBeNull() {
        String result = validatedConstructorCreatedInstanceMustNotBeNull$str();
        return result;
    }

    protected String validatedConstructorCreatedInstanceMustNotBeNull$str() {
        return validatedConstructorCreatedInstanceMustNotBeNull;
    }

    public final String inputStreamCannotBeNull() {
        String result = String.format(inputStreamCannotBeNull$str());
        return result;
    }

    protected String inputStreamCannotBeNull$str() {
        return inputStreamCannotBeNull;
    }

    public final String validatedObjectMustNotBeNull() {
        String result = validatedObjectMustNotBeNull$str();
        return result;
    }

    protected String validatedObjectMustNotBeNull$str() {
        return validatedObjectMustNotBeNull;
    }

    public final String beanTypeMustNotBeNull() {
        String result = beanTypeMustNotBeNull$str();
        return result;
    }

    protected String beanTypeMustNotBeNull$str() {
        return beanTypeMustNotBeNull;
    }

    public final String classIsNull() {
        String result = classIsNull$str();
        return result;
    }

    protected String classIsNull$str() {
        return classIsNull;
    }

    public final String beanTypeCannotBeNull() {
        String result = beanTypeCannotBeNull$str();
        return result;
    }

    protected String beanTypeCannotBeNull$str() {
        return beanTypeCannotBeNull;
    }

    public final String unableToFindScriptEngine(final String languageName) {
        String result = String.format(unableToFindScriptEngine$str(), languageName);
        return result;
    }

    protected String unableToFindScriptEngine$str() {
        return unableToFindScriptEngine;
    }

    public final String parameterMustNotBeEmpty(final String parameterName) {
        String result = String.format(parameterMustNotBeEmpty$str(), parameterName);
        return result;
    }

    protected String parameterMustNotBeEmpty$str() {
        return parameterMustNotBeEmpty;
    }

    public final String propertyNameMustNotBeEmpty() {
        String result = propertyNameMustNotBeEmpty$str();
        return result;
    }

    protected String propertyNameMustNotBeEmpty$str() {
        return propertyNameMustNotBeEmpty;
    }

    public final String parameterMustNotBeNull(final String parameterName) {
        String result = String.format(parameterMustNotBeNull$str(), parameterName);
        return result;
    }

    protected String parameterMustNotBeNull$str() {
        return parameterMustNotBeNull;
    }

    public final String groupMustNotBeNull() {
        String result = groupMustNotBeNull$str();
        return result;
    }

    protected String groupMustNotBeNull$str() {
        return groupMustNotBeNull;
    }

    public final String mustNotBeNull(final String parameterName) {
        String result = String.format(mustNotBeNull1$str(), parameterName);
        return result;
    }

    protected String mustNotBeNull1$str() {
        return mustNotBeNull1;
    }

    public final String validatedParameterArrayMustNotBeNull() {
        String result = validatedParameterArrayMustNotBeNull$str();
        return result;
    }

    protected String validatedParameterArrayMustNotBeNull$str() {
        return validatedParameterArrayMustNotBeNull;
    }

    public final String methodNameMustNotBeNull() {
        String result = methodNameMustNotBeNull$str();
        return result;
    }

    protected String methodNameMustNotBeNull$str() {
        return methodNameMustNotBeNull;
    }

    public final String validatedMethodMustNotBeNull() {
        String result = validatedMethodMustNotBeNull$str();
        return result;
    }

    protected String validatedMethodMustNotBeNull$str() {
        return validatedMethodMustNotBeNull;
    }

}
