package org.coode.owlapi.functionalparser;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

import org.semanticweb.owlapi.io.AbstractOWLParser;
import org.semanticweb.owlapi.io.OWLOntologyDocumentSource;
import org.semanticweb.owlapi.io.OWLParserException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyChangeException;
import org.semanticweb.owlapi.model.OWLOntologyFormat;
import org.semanticweb.owlapi.model.OWLOntologyLoaderConfiguration;
import org.semanticweb.owlapi.model.UnloadableImportException;


/**
 * Author: Matthew Horridge<br>
 * The University Of Manchester<br>
 * Bio-Health Informatics Group<br>
 * Date: 14-Nov-2006<br><br>
 */
public class OWLFunctionalSyntaxOWLParser extends AbstractOWLParser {

    public OWLOntologyFormat parse(OWLOntologyDocumentSource documentSource, OWLOntology ontology) throws OWLParserException, IOException, UnloadableImportException {
        return parse(documentSource, ontology, new OWLOntologyLoaderConfiguration());
    }

    public OWLOntologyFormat parse(OWLOntologyDocumentSource documentSource, OWLOntology ontology, OWLOntologyLoaderConfiguration configuration) throws OWLParserException, IOException, OWLOntologyChangeException, UnloadableImportException {
    	Reader reader = null;
    	InputStream is = null;
    	try {
            OWLFunctionalSyntaxParser parser;
            if(documentSource.isReaderAvailable()) {
            	reader = documentSource.getReader();
            	parser = new OWLFunctionalSyntaxParser(reader);
            }
            else if(documentSource.isInputStreamAvailable()) {
            	is = documentSource.getInputStream();
            	parser = new OWLFunctionalSyntaxParser(is);
            }
            else {
            	is = getInputStream(documentSource.getDocumentIRI());
            	parser = new OWLFunctionalSyntaxParser(is);
            }
            parser.setUp(ontology, configuration);
            return parser.parse();
        }
        catch (ParseException e) {
            throw new OWLParserException(e.getMessage(), e.currentToken.beginLine, e.currentToken.beginColumn);
        }
        finally {
        	if (is != null) {
        		is.close();
        	}
        	else if (reader != null) {
        		reader.close();
        	}
        }
    }
}
