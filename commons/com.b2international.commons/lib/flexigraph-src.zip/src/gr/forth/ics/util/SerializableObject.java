package gr.forth.ics.util;

import java.io.Serializable;

public final class SerializableObject implements Serializable {
    private static final long serialVersionUID = 0L;
}
