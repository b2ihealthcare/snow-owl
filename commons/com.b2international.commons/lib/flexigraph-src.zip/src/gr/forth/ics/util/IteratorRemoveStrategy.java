package gr.forth.ics.util;

public interface IteratorRemoveStrategy<E> {
      void removed(E element);
}
