package gr.forth.ics.graph.metrics;

import gr.forth.ics.graph.Node;

/**
 *
 * @author Andreou Dimitris, email: jim.andreou (at) gmail (dot) com
 */
public interface NodeMetric extends Metric<Node> {
}
